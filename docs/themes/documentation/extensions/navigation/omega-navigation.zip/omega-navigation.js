/**
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |o|m|e|g|a| |n|a|v|i|g|a|t|i|o|n|
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 * This is a mega-menu navigation extension.
 */

const omegaman = (function ($, window, document) {
	'use strict';

	let animationTimeout;
	let omegaActivator = document.querySelector('[data-hook~="activate-omega"]');
	let omegaNavigation = document.querySelector('[data-hook="omega-navigation"]');
	let omegaContent = document.querySelector('[data-hook="omega-navigation__content"]');
	let parentLinks = document.querySelectorAll('[data-hook~="omega-navigation__link"]');
	let childrenLinks = document.querySelector('[data-hook~="omega-navigation__children"]');
	let childrenBlocks = childrenLinks.children;
	let activeParent;
	let activeTarget;
	let mobileActivator = document.querySelector('[data-hook~="open-main-menu"]');
	let mobileCloser = document.querySelector('[data-hook~="close-main-menu"]');

	/**
	 * This function calculates the width of the scrollbar.
	 */
	function getScrollbarWidth() {
		return window.innerWidth - document.documentElement.clientWidth;
	}

	/**
	 * This function finds the first parent link and triggers a `click` event.
	 */
	function setInitial() {
		parentLinks.forEach(function (parent, index) {
			if (index === 0) {
				parent.click();
			}
		});
	}

	function smallerScreenFunctionality() {
		$.hook('omega-child-menu').children('a').on('click', function (event) {
			let selected = $(this);

			event.preventDefault();
			selected.next('ul').removeClass('is-hidden');
			selected.parent('.has-child-menu').closest('ul').addClass('show-next');
		});

		$.hook('show-previous-menu').on('click', function (event) {
			let selected = $(this);

			event.preventDefault();
			selected.parent('ul').addClass('is-hidden').parent('.has-children').closest('ul').removeClass('show-next');
		});
	}

	function largerScreenFunctionality() {
		/**
		 * Update the height of the child navigation container to accommodate a scrollbar if needed.
		 */
		omegaContent.style.height = omegaContent.scrollHeight + getScrollbarWidth() + 'px';

		/**
		 * When clicking on a parent category, show its children adn grandchildren.
		 */
		parentLinks.forEach(function (parentLink) {
			parentLink.addEventListener('click', function (event) {
				let target = '[data-hook~="' + this.getAttribute('data-children') + '"]';
				let targetChild = document.querySelector(target);

				if (targetChild === null) {
					return
				}

				event.preventDefault();

				parentLinks.forEach(function (sibling) {
					sibling.classList.remove('is-active');
				});

				Array.from(childrenBlocks).forEach(function (childBlock) {
					childBlock.classList.remove('is-active');
				});

				activeParent = this;
				activeTarget = targetChild;
				this.classList.add('is-active');
				targetChild.classList.add('is-active');
			});
		});
	}

	/**
	 * When opening the menu, set the first parent category as active.
	 */
	omegaActivator.addEventListener('click', function (event) {
		event.preventDefault();
		omegaNavigation.classList.toggle('is-open');
		document.documentElement.classList.toggle('has-active-navigation');
		setInitial();
	});

	/**
	 * Close the menu is the `Esc` key is pressed.
	 */
	window.addEventListener('keydown', function (keyEvent) {
		if (keyEvent.defaultPrevented) {
			return; // Do nothing if the event was already processed
		}

		switch (keyEvent.key) {
			case 'Escape':
				if (document.documentElement.classList.contains('has-active-navigation')) {
					omegaNavigation.classList.toggle('is-open');
					document.documentElement.classList.toggle('has-active-navigation');
					activeParent.classList.remove('is-active');
					activeTarget.classList.remove('is-active');
					setInitial();
				}
				break;
			default:
				return;
		}

		keyEvent.preventDefault();
	}, true);

	mobileActivator.addEventListener('click', function (event) {
		event.preventDefault();
		omegaNavigation.classList.toggle('is-open');
		document.documentElement.classList.toggle('has-active-navigation');
	});

	mobileCloser.addEventListener('click', function (event) {
		event.preventDefault();
		omegaNavigation.classList.toggle('is-open');
		document.documentElement.classList.toggle('has-active-navigation');
	});

	/**
	 * Check the screen size and run the appropriate functions.
	 */
	if (window.innerWidth < 992) {
		smallerScreenFunctionality();
	}
	else {
		largerScreenFunctionality();
	}

	window.addEventListener('resize', function () {
		if (animationTimeout) {
			window.cancelAnimationFrame(animationTimeout);
		}

		animationTimeout = window.requestAnimationFrame(function () {
			if (window.innerWidth < 992) {
				smallerScreenFunctionality();
			}
			else {
				largerScreenFunctionality();
			}
		});
	}, false);

})(jQuery, window, document);
